#pragma once
#include <windows.h>
#include <string>
#include <cstdint>

struct DllInfo {
    bool valid = false;
    std::wstring error;
    std::wstring machine = L"Unknown";
    uint64_t size = 0;
};

DllInfo InspectPeFile(const std::wstring& path);
std::wstring FormatBytes(uint64_t bytes);
