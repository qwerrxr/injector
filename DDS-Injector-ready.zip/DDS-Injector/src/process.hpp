#pragma once
#include <windows.h>
#include <string>
#include <vector>
#include <cstdint>

struct ProcessEntry {
    DWORD pid{};
    std::wstring name;
};

std::vector<ProcessEntry> EnumerateProcesses();
