#include "dll_info.hpp"
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>

#pragma pack(push, 1)
struct DosHeader {
    WORD magic;
    BYTE unused[58];
    LONG peOffset;
};
#pragma pack(pop)

DllInfo InspectPeFile(const std::wstring& path) {
    DllInfo info{};
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file) {
        info.error = L"Could not open the selected file.";
        return info;
    }

    const auto end = file.tellg();
    if (end < 0) {
        info.error = L"Could not determine file size.";
        return info;
    }
    info.size = static_cast<uint64_t>(end);
    if (info.size < sizeof(DosHeader)) {
        info.error = L"File is too small to be a valid PE image.";
        return info;
    }

    file.seekg(0);
    DosHeader dos{};
    file.read(reinterpret_cast<char*>(&dos), sizeof(dos));
    if (!file || dos.magic != 0x5A4D || dos.peOffset < 0) {
        info.error = L"Invalid DOS/PE header.";
        return info;
    }

    file.seekg(dos.peOffset);
    DWORD signature = 0;
    WORD machine = 0;
    file.read(reinterpret_cast<char*>(&signature), sizeof(signature));
    file.read(reinterpret_cast<char*>(&machine), sizeof(machine));
    if (!file || signature != 0x00004550) {
        info.error = L"PE signature not found.";
        return info;
    }

    switch (machine) {
        case IMAGE_FILE_MACHINE_I386:  info.machine = L"x86"; break;
        case IMAGE_FILE_MACHINE_AMD64: info.machine = L"x64"; break;
        case IMAGE_FILE_MACHINE_ARM64: info.machine = L"ARM64"; break;
        default: info.machine = L"Unknown (unsupported PE machine)"; break;
    }
    info.valid = true;
    return info;
}

std::wstring FormatBytes(uint64_t bytes) {
    const wchar_t* units[] = {L"B", L"KB", L"MB", L"GB"};
    double value = static_cast<double>(bytes);
    int unit = 0;
    while (value >= 1024.0 && unit < 3) {
        value /= 1024.0;
        ++unit;
    }
    std::wostringstream out;
    out << std::fixed << std::setprecision(unit == 0 ? 0 : 2)
        << value << L" " << units[unit];
    return out.str();
}
