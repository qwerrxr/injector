#include <windows.h>
#include <commdlg.h>
#include <d3d11.h>
#include <dxgi.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <algorithm>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "process.hpp"
#include "dll_info.hpp"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "comdlg32.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(
    HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static ID3D11Device* g_device = nullptr;
static ID3D11DeviceContext* g_context = nullptr;
static IDXGISwapChain* g_swapChain = nullptr;
static ID3D11RenderTargetView* g_mainRTV = nullptr;

static void CleanupRenderTarget() {
    if (g_mainRTV) { g_mainRTV->Release(); g_mainRTV = nullptr; }
}
static void CreateRenderTarget() {
    ID3D11Texture2D* backBuffer = nullptr;
    if (SUCCEEDED(g_swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer)))) {
        g_device->CreateRenderTargetView(backBuffer, nullptr, &g_mainRTV);
        backBuffer->Release();
    }
}
static bool CreateDeviceD3D(HWND hwnd) {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT flags = 0;
#ifdef _DEBUG
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
    D3D_FEATURE_LEVEL levels[] = {
        D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0
    };
    D3D_FEATURE_LEVEL obtained{};
    HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags,
        levels, ARRAYSIZE(levels), D3D11_SDK_VERSION, &sd,
        &g_swapChain, &g_device, &obtained, &g_context);

    if (FAILED(hr)) return false;
    CreateRenderTarget();
    return g_mainRTV != nullptr;
}
static void CleanupDeviceD3D() {
    CleanupRenderTarget();
    if (g_swapChain) { g_swapChain->Release(); g_swapChain = nullptr; }
    if (g_context) { g_context->Release(); g_context = nullptr; }
    if (g_device) { g_device->Release(); g_device = nullptr; }
}

struct LogLine { std::string text; ImVec4 color; };
static std::vector<LogLine> g_logs;
static std::vector<ProcessEntry> g_processes;
static int g_selectedProcess = -1;
static std::wstring g_dllPath;
static DllInfo g_dllInfo;
static HMODULE g_loadedPlugin = nullptr;

static std::string Narrow(const std::wstring& s) {
    if (s.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (n <= 1) return {};
    std::string out(static_cast<size_t>(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.c_str(), -1, out.data(), n, nullptr, nullptr);
    out.pop_back();
    return out;
}
static void Log(const std::string& message, ImVec4 color = ImVec4(0.72f,0.78f,0.86f,1)) {
    std::time_t now = std::time(nullptr);
    std::tm tmNow{};
    localtime_s(&tmNow, &now);
    std::ostringstream stamp;
    stamp << "[" << std::put_time(&tmNow, "%H:%M:%S") << "] ";
    g_logs.push_back({stamp.str() + message, color});
    if (g_logs.size() > 300) g_logs.erase(g_logs.begin());
}
static void RefreshProcesses() {
    g_processes = EnumerateProcesses();
    g_selectedProcess = -1;
    Log("Process list refreshed: " + std::to_string(g_processes.size()) + " entries.",
        ImVec4(0.35f,0.82f,0.55f,1));
}
static bool BrowseDll() {
    wchar_t path[MAX_PATH]{};
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = nullptr;
    ofn.lpstrFilter = L"Dynamic Link Libraries (*.dll)\0*.dll\0All files (*.*)\0*.*\0";
    ofn.lpstrFile = path;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrTitle = L"Select a DLL";
    if (!GetOpenFileNameW(&ofn)) return false;
    g_dllPath = path;
    g_dllInfo = InspectPeFile(g_dllPath);
    if (g_dllInfo.valid)
        Log("Selected DLL: " + Narrow(g_dllPath), ImVec4(0.35f,0.82f,0.55f,1));
    else
        Log("DLL inspection failed: " + Narrow(g_dllInfo.error), ImVec4(1,0.40f,0.35f,1));
    return true;
}
static void ApplyStyle() {
    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 8.0f;
    s.ChildRounding = 6.0f;
    s.FrameRounding = 5.0f;
    s.PopupRounding = 5.0f;
    s.ScrollbarRounding = 8.0f;
    s.GrabRounding = 5.0f;
    s.WindowPadding = ImVec2(18, 16);
    s.FramePadding = ImVec2(10, 7);
    s.ItemSpacing = ImVec2(10, 9);
    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg] = ImVec4(0.055f,0.065f,0.085f,1);
    c[ImGuiCol_ChildBg] = ImVec4(0.075f,0.088f,0.115f,1);
    c[ImGuiCol_FrameBg] = ImVec4(0.12f,0.14f,0.18f,1);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.16f,0.21f,0.29f,1);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.18f,0.25f,0.35f,1);
    c[ImGuiCol_TitleBg] = ImVec4(0.045f,0.055f,0.075f,1);
    c[ImGuiCol_TitleBgActive] = ImVec4(0.065f,0.085f,0.12f,1);
    c[ImGuiCol_Button] = ImVec4(0.12f,0.31f,0.58f,1);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.16f,0.40f,0.72f,1);
    c[ImGuiCol_ButtonActive] = ImVec4(0.10f,0.27f,0.50f,1);
    c[ImGuiCol_Header] = ImVec4(0.12f,0.29f,0.50f,0.75f);
    c[ImGuiCol_HeaderHovered] = ImVec4(0.16f,0.38f,0.62f,0.85f);
    c[ImGuiCol_CheckMark] = ImVec4(0.35f,0.68f,1.0f,1);
    c[ImGuiCol_SliderGrab] = ImVec4(0.25f,0.55f,0.90f,1);
    c[ImGuiCol_Border] = ImVec4(0.18f,0.22f,0.29f,1);
}
static void DrawUI() {
    ImGui::SetNextWindowPos(ImVec2(0,0));
    ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
    ImGui::Begin("DDS Injector", nullptr,
        ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);

    ImGui::TextColored(ImVec4(0.38f,0.68f,1.0f,1), "DDS");
    ImGui::SameLine();
    ImGui::Text("INJECTOR");
    ImGui::SameLine();
    ImGui::TextDisabled("v1.0  |  C++17 / WinAPI / ImGui");
    ImGui::Separator();

    ImGui::BeginChild("process_panel", ImVec2(0, 245), true);
    ImGui::Text("PROCESS EXPLORER");
    ImGui::SameLine();
    ImGui::TextDisabled("Read-only process list");
    ImGui::SameLine(ImGui::GetWindowWidth() - 105);
    if (ImGui::Button("Refresh")) RefreshProcesses();

    static char filter[128]{};
    ImGui::SetNextItemWidth(-1);
    ImGui::InputTextWithHint("##filter", "Filter processes by name...", filter, sizeof(filter));
    if (ImGui::BeginTable("process_table", 2,
        ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_RowBg |
        ImGuiTableFlags_ScrollY | ImGuiTableFlags_Resizable,
        ImVec2(0, 155))) {
        ImGui::TableSetupColumn("Process");
        ImGui::TableSetupColumn("PID", ImGuiTableColumnFlags_WidthFixed, 100);
        ImGui::TableHeadersRow();
        for (int i = 0; i < static_cast<int>(g_processes.size()); ++i) {
            const auto& p = g_processes[i];
            std::string name = Narrow(p.name);
            if (filter[0] && name.find(filter) == std::string::npos) continue;
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            char label[512];
            sprintf_s(label, "%s##%lu", name.c_str(), p.pid);
            if (ImGui::Selectable(label, g_selectedProcess == i,
                ImGuiSelectableFlags_SpanAllColumns))
                g_selectedProcess = i;
            ImGui::TableSetColumnIndex(1);
            ImGui::Text("%lu", p.pid);
        }
        ImGui::EndTable();
    }
    ImGui::EndChild();

    ImGui::BeginChild("dll_panel", ImVec2(0, 175), true);
    ImGui::Text("DLL INSPECTOR");
    ImGui::SetNextItemWidth(-115);
    std::string shownPath = Narrow(g_dllPath);
    ImGui::InputText("##dllpath", shownPath.data(), shownPath.size() + 1,
        ImGuiInputTextFlags_ReadOnly);
    ImGui::SameLine();
    if (ImGui::Button("Browse DLL")) BrowseDll();

    if (!g_dllPath.empty()) {
        ImGui::Text("File: %s", Narrow(g_dllPath.substr(g_dllPath.find_last_of(L"\\/") + 1)).c_str());
        ImGui::SameLine();
        ImGui::TextDisabled("| Size: %s", Narrow(FormatBytes(g_dllInfo.size)).c_str());
        ImGui::Text("PE architecture: %s", Narrow(g_dllInfo.machine).c_str());
        if (!g_dllInfo.valid)
            ImGui::TextColored(ImVec4(1,0.4f,0.35f,1), "%s", Narrow(g_dllInfo.error).c_str());
    } else {
        ImGui::TextDisabled("No DLL selected.");
    }
    ImGui::EndChild();

    ImGui::BeginChild("actions", ImVec2(0, 78), true);
    ImGui::Text("PLUGIN TEST");
    ImGui::SameLine();
    ImGui::TextDisabled("Loads a trusted DLL into this DDS process only.");
    ImGui::BeginDisabled(!g_dllInfo.valid || g_loadedPlugin != nullptr);
    if (ImGui::Button("Load plugin into DDS", ImVec2(190, 32))) {
        g_loadedPlugin = LoadLibraryW(g_dllPath.c_str());
        if (g_loadedPlugin)
            Log("Plugin loaded into DDS process.", ImVec4(0.35f,0.82f,0.55f,1));
        else
            Log("LoadLibrary failed. Win32 error: " + std::to_string(GetLastError()),
                ImVec4(1,0.40f,0.35f,1));
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (g_loadedPlugin && ImGui::Button("Unload plugin", ImVec2(130, 32))) {
        if (FreeLibrary(g_loadedPlugin)) {
            g_loadedPlugin = nullptr;
            Log("Plugin unloaded from DDS process.", ImVec4(0.35f,0.82f,0.55f,1));
        } else {
            Log("FreeLibrary failed.", ImVec4(1,0.40f,0.35f,1));
        }
    }
    ImGui::EndChild();

    ImGui::BeginChild("log_panel", ImVec2(0, 0), true);
    ImGui::Text("ACTIVITY LOG");
    ImGui::SameLine(ImGui::GetWindowWidth() - 75);
    if (ImGui::SmallButton("Clear")) g_logs.clear();
    ImGui::Separator();
    ImGui::BeginChild("log_scroller", ImVec2(0,0), false);
    for (const auto& line : g_logs)
        ImGui::TextColored(line.color, "%s", line.text.c_str());
    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 10)
        ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
    ImGui::EndChild();

    ImGui::End();
}

static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return TRUE;
    switch (msg) {
    case WM_SIZE:
        if (g_device && wParam != SIZE_MINIMIZED) {
            CleanupRenderTarget();
            g_swapChain->ResizeBuffers(0, (UINT)LOWORD(lParam),
                (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) return 0;
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int) {
    WNDCLASSEXW wc{sizeof(wc), CS_CLASSDC, WndProc, 0, 0, hInstance,
        nullptr, nullptr, nullptr, nullptr, L"DDSInjectorWindow", nullptr};
    RegisterClassExW(&wc);
    HWND hwnd = CreateWindowW(wc.lpszClassName, L"DDS Injector v1.0",
        WS_OVERLAPPEDWINDOW, 100, 100, 1050, 820,
        nullptr, nullptr, wc.hInstance, nullptr);

    if (!CreateDeviceD3D(hwnd)) {
        CleanupDeviceD3D();
        UnregisterClassW(wc.lpszClassName, wc.hInstance);
        MessageBoxW(nullptr, L"Failed to initialize Direct3D 11.",
            L"DDS Injector", MB_ICONERROR);
        return 1;
    }

    ShowWindow(hwnd, SW_SHOWDEFAULT);
    UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ApplyStyle();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_device, g_context);

    RefreshProcesses();
    Log("DDS Injector initialized.", ImVec4(0.35f,0.82f,0.55f,1));

    bool done = false;
    while (!done) {
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) done = true;
        }
        if (done) break;

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        DrawUI();
        ImGui::Render();

        const float clearColor[4] = {0.045f, 0.055f, 0.075f, 1.0f};
        g_context->OMSetRenderTargets(1, &g_mainRTV, nullptr);
        g_context->ClearRenderTargetView(g_mainRTV, clearColor);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_swapChain->Present(1, 0);
    }

    if (g_loadedPlugin) FreeLibrary(g_loadedPlugin);
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDeviceD3D();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}
