# DDS Injector v1.0 — Windows GUI shell

C++17 + WinAPI + Dear ImGui + DirectX 11.

This project is a process/DLL inspection utility and an in-process plugin demo.
It deliberately does **not** inject code or DLLs into other processes.

## Features
- Dark ImGui interface
- Refreshable process list (Toolhelp32)
- DLL file picker
- DLL file size and PE architecture inspection
- x86/x64 compatibility display
- Timestamped application log
- Optional loading of a selected plugin into this application itself

## Requirements
- Windows 10/11
- Visual Studio 2022 with **Desktop development with C++**
- Windows 10/11 SDK
- CMake 3.20+
- Dear ImGui (latest docking-independent release is fine)

## Add Dear ImGui
Download Dear ImGui from https://github.com/ocornut/imgui and copy its contents into
`vendor/imgui`, preserving this layout:

```
vendor/imgui/
  imgui.h
  imgui.cpp
  imgui_draw.cpp
  imgui_tables.cpp
  imgui_widgets.cpp
  backends/
    imgui_impl_win32.h
    imgui_impl_win32.cpp
    imgui_impl_dx11.h
    imgui_impl_dx11.cpp
```

## Build in Visual Studio
1. Open this folder in Visual Studio 2022 (`File > Open > Folder`).
2. Select the `x64-Debug` or `x64-Release` CMake configuration.
3. Build > Build All.
4. Run the `DDS-Injector` target.

Or from a Developer PowerShell:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

The executable will be at `build/Release/DDS-Injector.exe`.

## Notes
- The selected DLL is inspected as a PE file; it is not run automatically.
- `Load plugin into DDS` calls `LoadLibraryW` in the DDS process only. Use only DLLs
  you built and trust. A plugin's `DllMain` executes inside DDS.
- Process enumeration is read-only. Protected/system processes may show limited
  information and are not modified.
